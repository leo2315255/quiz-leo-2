
const firebaseConfig = {
    apiKey: "AIzaSyBD9pbsYFuoJIphkMyMT4HOIeWx3Blu6Kc",
    authDomain: "quizleo-cc6c8.firebaseapp.com",
    databaseURL: "https://quizleo-cc6c8-default-rtdb.firebaseio.com",
    projectId: "quizleo-cc6c8",
    storageBucket: "quizleo-cc6c8.appspot.com",
    messagingSenderId: "584038243305",
    appId: "1:584038243305:web:fd7d3ac374962e2aea0978"
};
firebase.initializeApp(firebaseConfig);
const db = firebase.database();
